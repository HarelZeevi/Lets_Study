import '../Styles/NotFound.css';

function NotFound() {
    return (
        <div>
            <br></br>
            <br></br>
            <br></br>
            <br></br>
            <br></br>
            <br></br>
            <h1 className='NFh1'>Page not found</h1>
            <p className='NFp'>Contact our support team if you need help</p>
        </div>
    )
}
export default NotFound;