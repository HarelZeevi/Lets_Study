class teacher
{
    constructor(id,name,pic,rate,grade,subject)
    {
        this.id = id,
        this.name = name,
        this.pic = pic,
        this.rate = rate,
        this.grade = grade,
        this.subject = subject
        // Ori/Harel, add the teacher's bio. - Ido
    }
}